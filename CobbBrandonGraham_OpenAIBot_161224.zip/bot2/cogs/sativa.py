''' sativa.py  The purpose of this program is to provide permission-restricted commands to OpenAIBot.
    Copyright (C) 2024  github.com/brandongrahamcobb

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''
from discord.ext import commands, tasks
from typing import Literal, Optional

import bot.utils.helpers as helpers
import discord

EMOJI_LEFT = "◀"
EMOJI_RIGHT = "▶"
EMOJI_EDIT = "✏️"
EMOJI_SAVE = "💾"
EMOJI_CANCEL = "❌"

user_configurations = {}

parameters_pages = [
    [
        ("model", "Model ID to use", "gpt-3.5-turbo", str),
        ("max_tokens/max_completion_tokens", "Max tokens (deprecated for some models). If the chosen model is o1-series use max_completion_tokens instead", 150, int),
        ("n", "Number of completions to generate", 1, int),
        ("temperature", "Sampling temperature (0-2)", 1.0, float),
    ],
    [
        ("top_p", "Nucleus sampling parameter (0-1)", 1.0, float),
        ("frequency_penalty", "Penalize repeated tokens (-2.0 to 2.0)", 0, float),
        ("presence_penalty", "Penalize repeating topics (-2.0 to 2.0)", 0, float),
        ("stream", "Stream responses? (true/false)", False, bool),
    ],
    [
        ("stop", "Stop sequence(s). Provide a string or comma-separated list.", None, str),
        ("store", "Store the output for future use (true/false)", False, bool),
        ("user", "Unique ID representing your end-user", None, str),
        ("service_tier", "Set service tier (auto, default)", "auto", str),
    ],
    [
        ("modalities", "Output types (e.g. [\"text\"], [\"text\",\"audio\"])", ["text"], list),
        ("metadata", "Developer-defined metadata (not editable via reactions, type manually)", None, str),
        ("response_format", "Response format object (not editable via reactions, type manually)", None, str),
        ("logit_bias", "Logit bias map (not editable via reactions)", None, dict),
    ]
]

def is_owner():
    async def predicate(ctx):
        return ctx.guild is not None and (ctx.guild.owner_id == ctx.author.id or ctx.author.id == 154749533429956608)
    return commands.check(predicate)

class Sativa(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='setup')
    async def setup_openai(self, ctx):
        """Start a multi-page parameter configuration setup for OpenAI Chat Completions."""
        user_id = str(ctx.author.id)
        
        # Load existing config or create a new one with defaults
        user_config = {}
        for page in parameters_pages:
            for (name, desc, default, ptype) in page:
                # For combined parameter like "max_tokens/max_completion_tokens"
                # we’ll store as "max_tokens" by default. The logic to switch 
                # could be applied later when making the API call.
                key = name.split('/')[0]
                user_config[key] = default
        
        # Current page index
        page_index = 0
        message = await ctx.send(embed=self.build_embed(ctx, user_config, page_index))

        # Add reactions for navigation and editing
        await message.add_reaction(EMOJI_LEFT)
        await message.add_reaction(EMOJI_RIGHT)
        await message.add_reaction(EMOJI_EDIT)
        await message.add_reaction(EMOJI_SAVE)
        await message.add_reaction(EMOJI_CANCEL)

        def check(reaction, user):
            return (
                user == ctx.author and
                reaction.message.id == message.id and
                str(reaction.emoji) in [EMOJI_LEFT, EMOJI_RIGHT, EMOJI_EDIT, EMOJI_SAVE, EMOJI_CANCEL]
            )

        while True:
            try:
                reaction, user = await self.bot.wait_for('reaction_add', timeout=120.0, check=check)
            except asyncio.TimeoutError:
                await ctx.send("Setup timed out. Please run the command again if you wish to configure.")
                await message.clear_reactions()
                return

            await message.remove_reaction(reaction, user)

            if str(reaction.emoji) == EMOJI_LEFT:
                page_index = (page_index - 1) % len(parameters_pages)
                await message.edit(embed=self.build_embed(ctx, user_config, page_index))

            elif str(reaction.emoji) == EMOJI_RIGHT:
                page_index = (page_index + 1) % len(parameters_pages)
                await message.edit(embed=self.build_embed(ctx, user_config, page_index))

            elif str(reaction.emoji) == EMOJI_EDIT:
                # Let the user pick a parameter index to edit from this page
                page_params = parameters_pages[page_index]
                params_desc = "\n".join([f"{i+1}. {p[0]}" for i, p in enumerate(page_params)])
                prompt_msg = await ctx.send(f"Which parameter would you like to edit?\n{params_desc}\nType a number or 'cancel' to abort.")
                
                def param_check(m):
                    return m.author == ctx.author and m.channel == ctx.channel

                try:
                    param_choice = await self.bot.wait_for('message', timeout=60.0, check=param_check)
                except asyncio.TimeoutError:
                    await ctx.send("No response. Returning to setup menu.")
                    await prompt_msg.delete()
                    continue
                
                choice_content = param_choice.content.lower().strip()
                await param_choice.delete()
                await prompt_msg.delete()

                if choice_content == 'cancel':
                    await ctx.send("Edit cancelled.")
                    continue

                if not choice_content.isdigit():
                    await ctx.send("Invalid choice. Must be a number.")
                    continue

                choice_index = int(choice_content) - 1
                if choice_index < 0 or choice_index >= len(page_params):
                    await ctx.send("Invalid choice.")
                    continue

                # Parameter chosen
                param_name, param_desc, param_default, param_type = page_params[choice_index]
                key = param_name.split('/')[0]  # handle combined name
                
                # Some parameters are complex (like dict), if it's too complex we skip editing:
                if param_type not in [str, int, float, bool, list]:
                    await ctx.send("This parameter is too complex to edit via reactions/text. Skipping.")
                    continue

                await ctx.send(f"Please provide a new value for **{param_name}** (Current: {user_config[key]}) or type 'cancel' to abort.\n**Description:** {param_desc}")

                try:
                    new_value_msg = await self.bot.wait_for('message', timeout=60.0, check=param_check)
                except asyncio.TimeoutError:
                    await ctx.send("No response. Keeping old value.")
                    continue
                
                new_value_str = new_value_msg.content.strip()
                await new_value_msg.delete()

                if new_value_str.lower() == 'cancel':
                    await ctx.send("Edit cancelled.")
                    continue

                # Convert the user input to the right type
                try:
                    if param_type == bool:
                        # Convert "true"/"false"
                        if new_value_str.lower() in ["true", "yes", "1"]:
                            converted_value = True
                        elif new_value_str.lower() in ["false", "no", "0"]:
                            converted_value = False
                        else:
                            raise ValueError("Invalid boolean value.")
                    elif param_type == int:
                        converted_value = int(new_value_str)
                    elif param_type == float:
                        converted_value = float(new_value_str)
                    elif param_type == list:
                        # For lists, assume comma-separated values
                        converted_value = [v.strip() for v in new_value_str.split(",")]
                    else:
                        # string fallback
                        converted_value = new_value_str
                except ValueError:
                    await ctx.send("Invalid value provided. Type conversion failed. Keeping old value.")
                    continue

                user_config[key] = converted_value
                await message.edit(embed=self.build_embed(ctx, user_config, page_index))
                await ctx.send(f"**{param_name}** updated to: {converted_value}")

            elif str(reaction.emoji) == EMOJI_SAVE:
                user_configurations[user_id] = user_config
                await ctx.send("Configuration saved successfully!")
                await message.clear_reactions()
                return

            elif str(reaction.emoji) == EMOJI_CANCEL:
                await ctx.send("Setup cancelled. Your changes have not been saved.")
                await message.clear_reactions()
                return

    def build_embed(self, ctx, config, page_index):
        page_params = parameters_pages[page_index]
        embed = discord.Embed(
            title="OpenAI Chat Completion Setup",
            description=f"Configure parameters - Page {page_index+1}/{len(parameters_pages)}",
            color=discord.Color.blue()
        )
        for (name, desc, default, ptype) in page_params:
            key = name.split('/')[0]
            current_val = config[key]
            embed.add_field(
                name=name,
                value=f"**Current:** {current_val}\n*{desc}*",
                inline=False
            )
        embed.set_footer(text="Use ◀ and ▶ to navigate pages, ✏️ to edit parameters, 💾 to save, ❌ to cancel.")
        return embed

    @commands.command(name='sync', hidden=True)
    @is_owner()
    async def sync(self, ctx: commands.Context, guilds: commands.Greedy[discord.Object], spec: Optional[Literal['~', '*', '^']] = None) -> None:
        if not guilds:
            if spec == '~':
                synced = await ctx.bot.tree.sync(guild=ctx.guild)
            elif spec == '*':
                ctx.bot.tree.copy_global_to(guild=ctx.guild)
                synced = await ctx.bot.tree.sync(guild=ctx.guild)
            elif spec == '^':
                ctx.bot.tree.clear_commands(guild=ctx.guild)
                await ctx.bot.tree.sync(guild=ctx.guild)
                synced = []
            else:
                synced = await ctx.bot.tree.sync()
            await ctx.send(
                f'Synced {len(synced)} commands {'globally' if spec is None else 'to the current guild.'}'
            )
            return
        ret = 0
        for guild in guilds:
            try:
                await ctx.bot.tree.sync(guild=guild)
            except discord.HTTPException:
                pass
            else:
                ret += 1
        await ctx.send(f'Synced the tree to {ret}/{len(guilds)}.')

async def setup(bot: commands.bot):
    await bot.add_cog(Sativa(bot))
